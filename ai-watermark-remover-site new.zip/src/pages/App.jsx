import React, { useState } from 'react';

const App = () => {
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleUpload = async () => {
    if (!file) return;
    setLoading(true);

    // Example API integration - replace with your actual endpoint
    const formData = new FormData();
    formData.append('image', file);

    try {
      const res = await fetch('https://your-api-endpoint.com/remove-watermark', {
        method: 'POST',
        body: formData,
      });

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setResult(url);
    } catch (err) {
      alert('Something went wrong!');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>AI Watermark Remover</h1>
      <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files[0])} />
      <br /><br />
      <button onClick={handleUpload} disabled={loading}>
        {loading ? 'Processing...' : 'Remove Watermark'}
      </button>
      <br /><br />
      {result && (
        <div>
          <h3>Result:</h3>
          <img src={result} alt="result" style={{ maxWidth: '100%' }} />
        </div>
      )}
    </div>
  );
};

export default App;
